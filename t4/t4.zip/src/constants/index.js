export const THEME_TYPE = {
  DARK: "DARK",
  LIGHT: "LIGHT",
};
