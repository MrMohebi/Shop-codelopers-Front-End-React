import React from "react";

const NameBox = () => {
  return (
    <div className="box">
      <span className="text-color">
        Lorem ipsum, dolor sit amet consectetur adipisicing elit
      </span>
    </div>
  );
};

export default NameBox;
